package com.project.bachelor.enogram;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;
//Author: Sonny Monti
//This Activity represents the main activity of Enogram, From here users can start the sequences of pictures.
public class MainBoard extends AppCompatActivity {

//    views and buttons fields
    private ImageButton button;
    private ImageButton button_options;
    private ImageView record_icon;
    private Button ftp_button;

//    normal fields
    protected boolean recording = false;

//    animations fields
    private Animation record_blink;
    private static Toast toastsucc;
    private static  Toast toastfail;
    private static ProgressBar mProgress;

//    Classes Fields
    private Photographer photo;
    private static FTPEnogram client;


//    @Override
//    protected void onDestroy(){
//        super.onDestroy();
//        photo.stopSequence();
//    }
//    @Override
//    protected void onPause(){
//        super.onPause();
//        photo.stopSequence();
//    }
//    @Override
//    protected void onStop(){
//        super.onStop();
//        photo.stopSequence();
//    }
//    This Method checks if there are enough parameters to start the ftp transfer
    public boolean canStart(){
        SharedPreferences settings = getSharedPreferences("ftp_data",MODE_PRIVATE);
        String ftp_server = settings.getString("ftp_server", "noserver");
        String ftp_password = settings.getString("ftp_password", "0");
        String ftp_user = settings.getString("ftp_user", "0");
        if(ftp_server == "noserver" || ftp_password == "0" || ftp_user == "0") {
            Toast toast = Toast.makeText(this, "Insufficient data to start FTP transfer", Toast.LENGTH_SHORT);
            toast.show();
            return false;
        }
        return true;
    }

    //    listener of the ftp button, that starts the upload
    private View.OnClickListener ftp_button_listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(canStart()) {
                Log.i("Info: ", "method startFTP called");
//            ProgressThread t = new ProgressThread();
//            t.run();
//            client.connectWithFtp();
            UploadDialog er = new UploadDialog();
            er.setCancelable(false);
            er.setContext(getApplicationContext());
            er.setActivity(MainBoard.this);
            er.show(MainBoard.this.getFragmentManager(), "erase");
            }
        }
    };

    //    Makes a spinner rotate when pictures are uploaded
    static private class UploadFileTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void ... params) {
            if(client.connectWithFtp()){
                toastsucc.show();
            }
            else {
                toastfail.show();
            }
            return null;
        }
        @Override
        protected void onPreExecute() {
            mProgress.setVisibility(View.VISIBLE);
            super.onPreExecute();
        }
        @Override
        protected void onPostExecute(Void c) {
            mProgress.setVisibility(View.GONE);
        }
    }

    /* Asks the user if he wants to upload the pictures */
    static public class UploadDialog extends DialogFragment {
        private Context context = null;
        private Activity activity = null;
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the Builder class for convenient dialog construction
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setMessage(R.string.dialog_upload)
                    .setPositiveButton(R.string.upload, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            mProgress.setVisibility(View.GONE);
                            UploadFileTask a = new UploadFileTask();
                            a.execute(null, null, null);
                        }
                    })
                    .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User cancelled the dialog
                            mProgress.setVisibility(View.GONE);
                        }
                    });
            // Create the AlertDialog object and return it
            return builder.create();
        }

        public void setContext(Context context) {
            this.context = context;
        }
        public void setActivity(Activity activity) {
            this.activity = activity;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        basic settages
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_board);

//        assign views and buttons
        record_icon = (ImageView)findViewById(R.id.record_icon);
        button = (ImageButton)findViewById(R.id.main_button);
        button_options = (ImageButton)findViewById(R.id.option_button);


//        gui and functional inits
        record_icon.setVisibility(View.INVISIBLE);
        button.setPressed(false);
//        contruct the class that controls the camera and generates the JSON
        photo = new Photographer(this, this);


        client = new FTPEnogram(this, this);
        toastfail = Toast.makeText(this, "No Pictures to Upload", Toast.LENGTH_SHORT);
        toastsucc = Toast.makeText(this, "transfer complete", Toast.LENGTH_SHORT);
        ftp_button = (Button) findViewById(R.id.button_ftp);
        ftp_button.setOnClickListener(ftp_button_listener);
        mProgress = (ProgressBar) findViewById(R.id.ftp_progress);




//        create animation that makes the record icon fade in and out during the record
        record_blink = new AlphaAnimation((float) 1, 0); // Change alpha from fully visible to invisible
        record_blink.setDuration(2000); // duration - 2 seconds
        record_blink.setInterpolator(new LinearInterpolator()); // do not alter animation rate
        record_blink.setRepeatCount(Animation.INFINITE); // Repeat animation infinitely
        record_blink.setRepeatMode(Animation.REVERSE); // Reverse animation at the end so the button will fade back
    }

//    This method is called from the start sequence button, it sets the animation, and starts the recording of pictures
    public void startPictures(View view){
        if (!recording) {
            recording = true;
            System.out.println("start");
            button.setActivated(true);
            button_options.setVisibility(View.INVISIBLE);
            record_icon.setVisibility(View.VISIBLE);
            record_icon.startAnimation(record_blink);
            if(photo.createJsonCollection()) {
                photo.startSequence();
            }
        } else {
            recording = false;
            System.out.println("stop");
            button.setActivated(false);
            button_options.setVisibility(View.VISIBLE);
            record_blink.cancel();
            record_icon.setVisibility(View.INVISIBLE);
            photo.stopSequence();
            photo.saveJson();
        }
    }

//    @Override
//    public void onStop(){
//        super.onStop();
//        if(photo != null){
//            photo.releaseCameraAndPreview();
//        }
//    }

//    This method opens the Options View
    public void openOptions(View view){
        Intent myIntent = new Intent(MainBoard.this, Options.class);
        MainBoard.this.startActivity(myIntent);
    }


}
