package com.project.bachelor.enogram;

/**
 * Created by Snie on 30.10.16.
 */

public class Localizer {
}
