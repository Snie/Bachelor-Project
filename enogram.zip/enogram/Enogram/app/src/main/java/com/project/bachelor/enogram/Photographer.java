package com.project.bachelor.enogram;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static android.content.Context.MODE_PRIVATE;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

/**
 * Created by Snie on 28.10.16.
 * this class is called when the user needs to start the sequence of photographies.
 * The pictures are stored in a external memory, with a unique nomenclature
 * This class also Keeps the current GPS coordinates to provide more infos
 * about the picture, A JSON with picture acquisition date and coordinates is also built.
 */

public class Photographer {
//FIELDS
    int progress;
    /*context and activity of the user*/
    private Context context;
    private Activity activity;
    private SharedPreferences sharedPreferences;
    private LocalData lc;

    /*Location services*/
    private static final int TWO_MINUTES = 1000 * 60 * 2;
    private Location currentLocation;
    private LocationManager lq;
    private String latitude;
    private String longitude;
    private float currentSpeed;

    /*camera and preview fields*/
    private Camera mCamera;
    private CameraPreview mPreview;
    private FrameLayout preview;
    private boolean isActive, isTaking;

    /*JSON fields*/
    private JSONObject collection;

    /*threads and processes*/
    private Timer tim;

    /*android pieces*/
    private TextView view_latitude, view_longitude, view_speed, view_name, view_progress;




//    LISTENERS AND OVERRIDES

    /* An override of the location listener to update the currentlocation*/
    private  LocationListener locationListener = new LocationListener() {
        public void onLocationChanged(Location location) {
            /*Called when a new location is found by the network location provider.*/
            if(isBetterLocation(location, currentLocation)) {
                latitude = Double.toString(location.getLatitude());
                longitude = Double.toString(location.getLongitude());
                currentSpeed = location.getSpeed();
                view_latitude.setText(latitude);
                view_longitude.setText(longitude);
                view_speed.setText(currentSpeed + "");
                currentLocation = location;
            }
        }
        public void onStatusChanged(String provider, int status, Bundle extras) {}
        public void onProviderEnabled(String provider) {}
        public void onProviderDisabled(String provider) {}
    };


    /*an override of the picture callback, called when a picture is taken*/
    Camera.PictureCallback mPicture = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            File pictureFile = null;
            try {
                pictureFile = createImageFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (pictureFile == null) {
                return;
            }
            try {
                /* Increment the counter of the pictures taken */
                progress++;
                FileOutputStream fos = new FileOutputStream(pictureFile);
                /* Write the picture data in the file */
                fos.write(data);
                fos.close();
                Log.i("CAMERA", "picture created and saved in: " + pictureFile.getAbsolutePath());
//                System.out.println(pictureFile.getName());
                /* insert the taken picture in the JSON */
                putJson(collection, pictureFile.getName(), latitude, longitude);
                setProgress(progress);
            } catch (FileNotFoundException e) {
                Log.e("File error", "File not found");
            } catch (IOException e) {
                Log.e("IO error", "IO Exception");
            }
        }
    };


    // CONSTRUCTOR
    public Photographer(Context context, Activity activity){
        /*saves context and activity of the caller*/
        this.context = context;
        this.activity = activity;

        /*prepare camera preview*/
        preview = (FrameLayout) this.activity.findViewById(R.id.camera_preview);
        tim = new Timer(true);

        /*other views*/
        view_latitude = (TextView)activity.findViewById(R.id.view_latitude);
        view_longitude = (TextView)activity.findViewById(R.id.view_longitude);
        view_speed = (TextView)activity.findViewById(R.id.view_speed);
        view_name = (TextView)activity.findViewById(R.id.view_name);
        view_progress = (TextView)activity.findViewById(R.id.view_progress);
        view_latitude.setTypeface(null, Typeface.BOLD);
        view_longitude.setTypeface(null, Typeface.BOLD);
        view_speed.setTypeface(null, Typeface.BOLD);
        view_progress.setTypeface(null, Typeface.BOLD);
        view_name.setTypeface(null, Typeface.BOLD);
        view_name.setVisibility(View.GONE);
        view_progress.setVisibility(View.GONE);

        sharedPreferences = context.getSharedPreferences("ftp_data",MODE_PRIVATE);
        lc = new LocalData();

        /*check if the external storage is avaiable
        * */
        if(isExternalStorageWritable()) {

            /*get location manager*/
            lq = (LocationManager) this.context.getSystemService(Context.LOCATION_SERVICE);

            if (ContextCompat.checkSelfPermission(this.context, Manifest.permission.ACCESS_FINE_LOCATION) == PERMISSION_GRANTED) {
                /*binds the overidden location listener to the Location services*/
                lq.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                lq.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
                /* Check which provider location is more accurate */
                if(lq != null){
                    Location gps_location = lq.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    Location network_location = lq.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    long current_time = System.currentTimeMillis();
                    long gps_time = Math.abs(gps_location.getTime() - current_time)/1000;
                    long network_time = Math.abs(network_location.getTime() - current_time)/1000;
                    Location closer = null;
                    if(network_time < 60){
                        closer = (gps_time < network_time) ? gps_location : network_location;
                        currentLocation = closer;
                    }
                    if(gps_time < 60){
                        closer = network_time < gps_time ? network_location : gps_location;
                        currentLocation = closer;
                    }
                    if(closer != null){
                        latitude =  Double.toString(closer.getLatitude());
                        longitude = Double.toString(closer.getLongitude());
                    }

                }
            }
        }
        else {
            Toast toast = Toast.makeText(this.context, "No external memory found", Toast.LENGTH_SHORT);
            toast.show();
        }
        /*check for camera hardware*/
        if(checkCameraHardware(this.context)){
            /*check if camera can be opened correctly then open the preview*/
            if(safeCameraOpen(0)) {
                Camera.Parameters params = mCamera.getParameters();
//                DIFFERENT CAMERA RESOLUTIONS
//                List<Camera.Size> supportedSizes = params.getSupportedPictureSizes();
//                for(Camera.Size i : supportedSizes){
//                    System.out.println("cam size: W "+i.width+" H "+i.height);
//                }
//                Camera.Size sizePicture = supportedSizes.get(8);
//                params.setPictureSize(sizePicture.width, sizePicture.height);
                /* Activate autofocus and iso to make images more defined */
                params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
                params.set("iso","auto");
                params.setRotation(270);
                mCamera.setParameters(params);
                /* This was to take the sceenshots of the preview */
//                mCamera.setPreviewCallback(mPreviewCallback);

                 /*Create the Preview view and set it */
                mPreview = new CameraPreview(this.context, mCamera);
                preview.addView(mPreview);
            }

        }
    }

    /*this method creates picture with a unique name*/
    public File createImageFile() throws IOException {
        /*Create an image file name*/
        String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss_S").format(new Date());
        String imageFileName =  timeStamp;
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);

//        putJson(collection, imageFileName+".jpg", latitude, longitude);

        System.out.println("new file located ind: "+storageDir.getAbsolutePath()+" name is: "+imageFileName);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        return image;
    }


    /* Hardware checks */
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }
    public boolean checkCameraHardware(Context context) {
        if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)){
            // this device has a camera
            return true;
        } else {
            // no camera on this device
            return false;
        }
    }

    /** A safe way to get an instance of the Camera object. */
    public boolean safeCameraOpen(int id) {
        boolean qOpened = false;

        try {
            releaseCameraAndPreview();
            mCamera = Camera.open(id);
            qOpened = (mCamera != null);
            isActive = true;
        } catch (Exception e) {
            Log.e(context.getString(R.string.app_name), "failed to open Camera");
            e.printStackTrace();
        }

        return qOpened;
    }

    public void releaseCameraAndPreview() {
        isActive = false;
        if (mCamera != null) {
            mCamera.release();
        }
    }
    /* This Method is called from the mainboard to start a sequence of pictures with a interval*/
    public void startSequence(){
        progress = 0;
        isTaking = true;
        String tmp = "";
        try {
            tmp = collection.getString("timestamp");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        view_name.setText(tmp);
        view_name.setVisibility(View.VISIBLE);
        view_progress.setVisibility(View.VISIBLE);
        tim = null;
        tim = new Timer();
        int timing = lc.getDistance(sharedPreferences) * 1000;
        tim.schedule(new Sequence(), 0,timing );
    }

    public void stopSequence(){
        progress = 0;
        isTaking = false;
        view_name.setVisibility(View.GONE);
        view_progress.setVisibility(View.GONE);
        tim.cancel();
        tim = null;
    }


//    JSON UTILS

    /*creates a json with the current time and the gps data and name of the
    sequence of pictures, The json structure is like this:
    collection =    {
                        timestamp : unique timestamp,
                        pictures :  [
                                        {name : 2016_11_08_18_44_01_5,
                                        latitude: current latitude,
                                        longitude: current longitude
                                        },
                                        {name : 2016_11_08_18_44_01_10,
                                        latitude: current latitude,
                                        longitude: current longitude
                                        }
                                    ]
                    };
    */

    public boolean createJsonCollection(){
        JSONObject tmp = new JSONObject();
        JSONArray arr = new JSONArray();
        try {
            tmp.put("timestamp", new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date()));
            tmp.put("pictures", arr);
            collection = tmp;
            return true;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }

    /*insert new photo data into a JSON collection of pictures*/

    public boolean putJson(JSONObject json, String name, String lat, String lon){
        JSONObject tmp = new JSONObject();
        try {
            tmp.put("name", name);
            tmp.put("latitude", lat);
            tmp.put("longitude", lon);
            JSONArray arr =  json.getJSONArray("pictures");
            arr.put(tmp);
            json.put("pictures", arr);
            return true;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }

    /*saves the JSON that represent the current sequence of picture in the documents folder of enogram*/
    public boolean saveJson(){
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        Log.i("JSON","json is being saved in: "+storageDir.getAbsolutePath());
        /*creates the file to write with the unique collection timestamp*/
        try {
            collection.put("user", lc.getFtpUser(sharedPreferences));
            collection.put("device", Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ANDROID_ID));
            File image = File.createTempFile(
                    collection.getString("timestamp"),  /* prefix */
                    ".txt",         /* suffix */
                    storageDir      /* directory */
            );
            FileOutputStream fos = new FileOutputStream(image);
            fos.write(collection.toString().getBytes());
            fos.close();
            Log.i("JSON","json correctly saved");
            return true;

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }


//    GETTERS AND SETTERS

    public boolean isActive() {
        return isActive;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public float getCurrentSpeed() {
        return currentSpeed;
    }

    /* The class that physically takes pictures */
    class Sequence extends TimerTask {
        public void run() {
            mCamera.takePicture(null, null, mPicture);
            Log.i("CAMERA", "picture dispatched");
            mCamera.stopPreview();
            mCamera.startPreview();

//            try {
//                File tmp = createImageFile2();
//                putJson(collection, tmp.getName(), latitude, longitude);
//
//            } catch (IOException e) {
//                e.printStackTrace();
//            }

        }
    }
    /* A method that returns the file pointer of a picture from a picture name*/
    private File getPicture(String filename){
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        for (final File fileEntry : storageDir.listFiles()) {
            if (fileEntry.isDirectory()) {
//                                directory found
            } else {
                if(fileEntry.getName().substring(fileEntry.getName().length() - 3).equals(".jpg")){
                    fileEntry.delete();
                    Log.w("INVALID PHOTO", "Invalid file found in Photos directory");
                }
                else{
                    if(fileEntry.getName().equals(filename)) return fileEntry;
                }
            }
        }
        return null;
    }


    /* Method that updates the number of pictures in the view */
    public void setProgress(int progress){
        view_progress.setText(""+progress);
    }

    /** Determines whether one Location reading is better than the current Location fix
     * @param location  The new Location that you want to evaluate
     * @param currentBestLocation  The current Location fix, to which you want to compare the new one
     */
    protected boolean isBetterLocation(Location location, Location currentBestLocation) {
        if (currentBestLocation == null) {
            // A new location is always better than no location
            return true;
        }

        // Check whether the new location fix is newer or older
        long timeDelta = location.getTime() - currentBestLocation.getTime();
        boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
        boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
        boolean isNewer = timeDelta > 0;

        // If it's been more than two minutes since the current location, use the new location
        // because the user has likely moved
        if (isSignificantlyNewer) {
            return true;
            // If the new location is more than two minutes older, it must be worse
        } else if (isSignificantlyOlder) {
            return false;
        }

        // Check whether the new location fix is more or less accurate
        int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
        boolean isLessAccurate = accuracyDelta > 0;
        boolean isMoreAccurate = accuracyDelta < 0;
        boolean isSignificantlyLessAccurate = accuracyDelta > 200;

        // Check if the old and new location are from the same provider
        boolean isFromSameProvider = isSameProvider(location.getProvider(),
                currentBestLocation.getProvider());

        // Determine location quality using a combination of timeliness and accuracy
        if (isMoreAccurate) {
            return true;
        } else if (isNewer && !isLessAccurate) {
            return true;
        } else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider) {
            return true;
        }
        return false;
    }

    /** Checks whether two providers are the same */
    private boolean isSameProvider(String provider1, String provider2) {
        if (provider1 == null) {
            return provider2 == null;
        }
        return provider1.equals(provider2);
    }



//    NOT USED METHODS

    //    These methods were intended to snap pictures from the preview of the camera,
//    I didnt used them because it was unstable in terms of camera efficience
    Camera.PreviewCallback mPreviewCallback = new Camera.PreviewCallback() {
        @Override
        public void onPreviewFrame(byte[] data, Camera camera) {
            if(isTaking) {
                Camera.Parameters parameters = camera.getParameters();
                int imageFormat = parameters.getPreviewFormat();
                if (imageFormat == ImageFormat.NV21) {
                    Rect rect = new Rect(0, 0, 1920, 1080);
                    YuvImage img = new YuvImage(data, ImageFormat.NV21, 1920, 1080, null);
                    OutputStream outStream = null;
                    File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                    File file = new File(storageDir.getAbsolutePath() + "/tmp.jpg");
                    try {
                        outStream = new FileOutputStream(file);
                        img.compressToJpeg(rect, 100, outStream);
                        outStream.flush();
                        outStream.close();
                        System.out.println("preview saved in " + file.getAbsolutePath());
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    };
    public File createImageFile2() throws IOException {
        /*Create an image file name*/
        String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss_S").format(new Date());
        String imageFileName =  timeStamp;
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);

//        putJson(collection, imageFileName+".jpg", latitude, longitude);

        System.out.println("new file located ind: "+storageDir.getAbsolutePath()+" name is: "+imageFileName);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        File tmp = getPicture("tmp.jpg");
//        BufferedReader inputStream = new BufferedReader(new FileReader(
//                tmp.getAbsolutePath()));
//        FileWriter filewriter = new FileWriter(image.getAbsoluteFile());
//        BufferedWriter outputStream= new BufferedWriter(filewriter);
//        int count = (int)tmp.length();
//        byte[] data = new byte[count];
//        int bytesRead = inputStream.read(data, 0, count);
//        if (bytesRead != count) System.err.println(" -- asd");
//        outputStream.write(data, 0, count);
//        outputStream.flush();
//        outputStream.close();
//        inputStream.close();

        InputStream is = null;
        OutputStream os = null;
        try {
            is = new FileInputStream(tmp);
            os = new FileOutputStream(image);
            byte[] buffer = new byte[(int)tmp.length()];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }}catch(IOException e){
            e.printStackTrace();
        }finally {
            is.close();
            os.close();
        }
        return image;
    }
}
