package com.project.bachelor.enogram;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;


/**
 * Created by Snie on 30.10.16.
 * This class is needed to keep saved the options of the user
 */

public class LocalData{
    SharedPreferences settings;
    SharedPreferences.Editor editor;
    public LocalData(){
    }

    public void saveFtpServer(String ftp_server, SharedPreferences.Editor editor){
        editor.putString("ftp_server", ftp_server);
        editor.commit();
    }

    public void saveFtpPassword(String ftp_password, SharedPreferences.Editor editor){
        editor.putString("ftp_password", ftp_password);
        editor.commit();
    }
    public void saveDistance(int distance, SharedPreferences.Editor editor) {
        editor.putInt("distance", distance);
        editor.commit();
    }
    public void saveFtpUsername(String ftp_username, SharedPreferences.Editor editor){
        editor.putString("ftp_username", ftp_username);
        editor.commit();
    }

    public void saveFtpUser(String ftp_user, SharedPreferences.Editor editor){
        editor.putString("ftp_user", ftp_user);
        editor.commit();
    }
    public void saveCrop(String crop, SharedPreferences.Editor editor){
        editor.putString("crop", crop);
        editor.commit();
    }



    public boolean isValidFtpServer(String ftp_server) {return !ftp_server.equals("noserver ");}
    public boolean isValidFtpPassword(String ftp_password) {
        return !ftp_password.equals("0 ");
    }
    public boolean isValidDistance(int distance) {
        return distance != -1;
    }
    public boolean isValidFtpUsername(String username) {return !username.equals("-1");}
    public boolean isValidFtpUser(String user) {return !user.equals("-1");}
    public boolean isValidCrop(String crop) {return !crop.equals("-1");}



    public String getFtpServer(SharedPreferences settings){return settings.getString("ftp_server", "noserver");}
    public String getFtpPassword(SharedPreferences settings){return settings.getString("ftp_password", "0");}
    public int getDistance(SharedPreferences settings) {return (int) settings.getInt("distance", -1);}
    public String getFtpUsername(SharedPreferences settings) {return settings.getString("ftp_username", "-1");}
    public String getFtpUser(SharedPreferences settings) {return settings.getString("ftp_user", "-1");}
    public String getCrop(SharedPreferences settings) {return settings.getString("crop", "-1");}
}
