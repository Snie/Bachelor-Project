package com.project.bachelor.enogram;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.io.CopyStreamAdapter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Snie on 11.11.16.
 * THis class uploads pictures to the ftp server
 */

public class FTPEnogram {
    private String name;

    private FTPClient client;
    private LocalData lc;
    private Context context;
    private Activity activity;
    private String host, userName, pass;
    private SharedPreferences sharedPreferences;
    private static ProgressBar mProgress;


    private int percent;
    private int collections_size;
    private int collection_progress;


    public FTPEnogram(Context context, Activity activity){
        lc = new LocalData();
        this.context = context;
        this.activity = activity;
        sharedPreferences = context.getSharedPreferences("ftp_data",MODE_PRIVATE);
        mProgress = (ProgressBar) activity.findViewById(R.id.ftp_progress);
    }

    /*Method to start the upload*/
    public boolean startUpload(FTPClient client){
        String baseFolder = "/enogram";
        /* becomes false if upload errorw  */
        boolean success = true;
        /* get the json collections of pictures to find the picture files */
        List<JsonCollection> collections = parseCollections();
        if(collections.size() == 0){
            Toast toast = Toast.makeText(context, "To upload a colelction you must first create one", Toast.LENGTH_SHORT);
            toast.show();
            success = false;
        }
        else {
            /* Iterates in each collection of pictures*/
            for(int i = 0; i < collections.size(); i++) {
                JsonCollection collection = collections.get(i);
                /* enters in the base folder of Enogram /enogram*/
                if (changeFolder(client, baseFolder)) {
                    /* Enters in the crop folder*/
                    if(changeFolder(client, lc.getCrop(sharedPreferences))){
                        try {
                            /* Create a folder named as the collection is, Checks if collection already exists, if yes it doesnt upload*/
                            boolean tmp = client.changeWorkingDirectory(collection.getName() + "#" + collection.getUser());
                            if(!tmp) {
                                if (changeFolder(client, collection.getName() + "#" + collection.getUser())) {
                                    List<File> pictures = collection.getPictures();
                                    pictures.add(collection.getJson_file());
                                    /* Finally uploads the pictures */
                                    for (File tmpFile : collection.getPictures()) {
                                        File firstLocalFile = tmpFile;
                                        String firstRemoteFile = tmpFile.getName();
                                        InputStream inputStream;
                                        inputStream = new FileInputStream(firstLocalFile);
                                        System.out.println("Start uploading: " + firstRemoteFile);
                                        boolean done = client.storeFile(firstRemoteFile, inputStream);
                                        inputStream.close();
                                        if (done) {
                                            System.out.println(firstRemoteFile + " uploaded successfully: "+percent+"t0t size "+collections_size);
                                        }
                                        else{
                                            System.out.println(firstRemoteFile + " not uploaded");
                                            success = false;
                                        }
                                    }

                                }
                            }
                        } catch (IOException e){
                            e.printStackTrace();
                            success = false;
                        }

                    }
                } else {
                    Toast toast = Toast.makeText(context, "Errors in FTP server", Toast.LENGTH_SHORT);
                    toast.show();
                    success = false;
                }
            }
        }
        int u;
        return success;
    }
    /* Method that opens the FTP connection*/
    public boolean connectWithFtp(){
        host = lc.getFtpServer(sharedPreferences);
        pass = lc.getFtpPassword(sharedPreferences);
        userName = lc.getFtpUsername(sharedPreferences);
        String user = lc.getFtpUser(sharedPreferences);
        boolean ret = true;
        client = new FTPClient();
        FTPClientConfig config = new FTPClientConfig();
        client.configure(config);

        if(lc.isValidFtpUser(user) && lc.isValidFtpUsername(userName) && lc.isValidFtpPassword(pass) && lc.isValidFtpServer(host)) {
//        client.setCopyStreamListener(streamListener);
            Log.i("INFO", "started ");
//        client.setConnectTimeout(10 * 1000);
            try {
                int reply;
                client.connect(host, 21);
//            client.login(userName,pass);
                client.enterLocalPassiveMode();
                client.setFileType(FTP.BINARY_FILE_TYPE);
                if (client.isConnected()) {
                    Log.i("Buffer Size:", "" + client.getBufferSize());
                    this.client.setBufferSize(1024 * 1024);
                    Log.i("Buffer Size:", "" + client.getBufferSize());
                    System.out.println("Connected to " + host + ".");
                    System.out.print(client.getReplyString());

                    // After connection attempt, you should check the reply code to verify
                    // success.
                    reply = client.getReplyCode();
                    if (!FTPReply.isPositiveCompletion(reply)) {
                        client.disconnect();
                        System.err.println("FTP server refused connection.");
                        System.exit(1);
                        ret = false;
                        return ret;
                    }
                    if (!client.login(userName, pass)) {
                        client.logout();
                        Toast toast = Toast.makeText(context, "Invalid login data for: " + host, Toast.LENGTH_SHORT);
                        toast.show();
                        ret = false;
                        return ret;
                    }
                    /* If everything goes allright, the connection is stable, the program start the upload of the pictures and
                    * at the end ask if keep or delete the pictures*/
                    if (startUpload(client)) {
                        Log.i("FTP", "transfer complete");
                        EraseDialog er = new EraseDialog();
                        er.setCancelable(false);
                        er.setContext(context);
                        er.setActivity(activity);
                        er.show(activity.getFragmentManager(), "erase");
                        ret = true;
                    }
                    client.logout();
                    return ret;
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (client.isConnected()) {
                    try {
                        client.disconnect();
//                    mProgress.setVisibility(View.GONE);
                        Log.i("FTP TRANSFER", "Connection with: " + host + " closed");
                    } catch (IOException ioe) {
                        // do nothing
                    }
                }
                return ret;
            }
        }
        else{
            Toast toast = Toast.makeText(context, "Not enough data to start FTP", Toast.LENGTH_SHORT);
            toast.show();
            return ret;
        }
    }
    /* Method that change folder, and create it if doesnt exist*/
    public boolean changeFolder(FTPClient client, String folder){
        boolean success = false;
        try {
            success = client.changeWorkingDirectory(folder);
            if(success){
                return success;
            }
            else{
                boolean tmp1 = client.makeDirectory(folder);
                boolean tmp2 = client.changeWorkingDirectory(folder);
                success = (tmp1 && tmp2);
                return success;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return success;
    }

    /* Method that searches the pictures from the json representing them*/
    public List<JsonCollection> parseCollections(){
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        List<JsonCollection> out = new ArrayList<>();
        collections_size = 0;
        collection_progress = 0;
        for (final File fileEntry : storageDir.listFiles()) {
            if (fileEntry.isDirectory()) {
//                                directory found
            }
            else {
//                eventual anonimous fies in the documents of Enogram are deleted
                if(fileEntry.getName().substring(fileEntry.getName().length() - 3).equals(".txt")){
                    boolean tmp = fileEntry.delete();
                    Log.w("INVALID JSON", "Invalid file found in Documents directory: "+fileEntry.getName());
                    if(!tmp){
                        Log.w("INVALID JSON", "failed to delete JSON");
                    }
                }
                else{
                    /*creates the json object from the txt file */
                    JSONObject collection = jsonGenerator(fileEntry);
                    if(collection != null){
                        /* gets the pictures pointers from the json */
                        List<File> pictures = getPicturesFromJson(collection);
                        String user = "";
                        String device = "";
                        try {
                            user = collection.getString("user");
                            device = collection.getString("device");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        out.add(new JsonCollection(name,device,user, pictures, jsonGenerator(fileEntry), fileEntry));
                    }
                    else {
                        Log.w("INVALID JSON", "failed to parse JSON: "+fileEntry.getName());
                    }
                }
            }
        }
        return out;
    }

    /* Method that returns a list of file pointers from a json containing the path of these files*/
    public List<File> getPicturesFromJson(JSONObject collection){
        List<File> out = new ArrayList<>();
        try {
            name = collection.getString("timestamp");
            JSONArray pictures = collection.getJSONArray("pictures");
            int len = pictures.length();
            for(int i = 0; i < len; i++){
                JSONObject picture = pictures.getJSONObject(i);
                String picture_name = picture.getString("name");
                File toWrite = getPicture(picture_name);
                if(toWrite != null){
                    collections_size += toWrite.length();
                    out.add(toWrite);
                }
            }
//            out.add(getPicture("tmp.jpg"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return out;
    }
    /* Method that takes a txt file representing a json, an returns a JSON Object*/
    private JSONObject jsonGenerator(File json){
        JSONObject out = null;
        try {
            StringBuilder builder = new StringBuilder();
            String string_json;
            BufferedReader in;
            in = new BufferedReader(new FileReader(json));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line);
            }
            string_json = builder.toString();
            in.close();
            out = new JSONObject(string_json);
            return out;
        } catch (IOException | JSONException e){
            e.printStackTrace();
        }
        return out;
    }

    /* Searches for a given picture in the directory pictures, and return the pointer to it */
    private File getPicture(String filename){
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        for (final File fileEntry : storageDir.listFiles()) {
            if (fileEntry.isDirectory()) {
//                                directory found
            } else {
                if(fileEntry.getName().substring(fileEntry.getName().length() - 3).equals(".jpg")){
                    fileEntry.delete();
                    Log.w("INVALID PHOTO", "Invalid file found in Photos directory");
                }
                else{
                    if(fileEntry.getName().equals(filename)) return fileEntry;
                }
            }
        }
        return null;
    }
    public static void deleteAll(Context context, Activity activity) {
        boolean success = false;
        File storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File jsonDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        for (final File fileEntry : storageDir.listFiles()) {
            if (fileEntry.isDirectory()) {
            } else {
                success = fileEntry.delete();
            }
        }
        for (final File fileEntry : jsonDir.listFiles()) {
            if (fileEntry.isDirectory()) {
            } else {
                success = fileEntry.delete();
            }
        }
    }
    /* A inner class representing the JSON*/
    private class JsonCollection{
        private String name;
        private String device;
        private String user;
        private List<File> pictures;
        private JSONObject json;
        private File json_file;

        public JsonCollection(String name, String device, String user, List<File> pictures, JSONObject json, File json_file){
            this.name = name;
            this.pictures = pictures;
            this.json = json;
            this.device = device;
            this.user = user;
            this.json_file = json_file;
        }

        public List<File> getPictures() {
            return pictures;
        }

        public String getName() {
            return name;
        }

        public JSONObject getJson() {
            return json;
        }

        public String getUser() {
            return user;
        }

        public String getDevice() {
            return device;
        }

        public File getJson_file() {
            return json_file;
        }
    }

    /* When pictures finishes to be uploaded, the user can delete them or can keep them*/
    static public class EraseDialog extends DialogFragment {
        private Context context = null;
        private Activity activity = null;
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the Builder class for convenient dialog construction
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setMessage(R.string.dialog_erase)
                    .setPositiveButton(R.string.erase, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            deleteAll(context, activity);
                            mProgress.setVisibility(View.GONE);
                        }
                    })
                    .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User cancelled the dialog
                            mProgress.setVisibility(View.GONE);
                        }
                    });
            // Create the AlertDialog object and return it
            return builder.create();
        }

        public void setContext(Context context) {
            this.context = context;
        }
        public void setActivity(Activity activity) {
            this.activity = activity;
        }
    }

}
