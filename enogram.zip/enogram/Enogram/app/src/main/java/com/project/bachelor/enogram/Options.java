package com.project.bachelor.enogram;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

/*
* Author: Sonny Monti
* This Activity is needed to set the user options, such as the FTP parameters and the timing of the pictures.
* And this is also the view in which the user sends the pictures to the ftp server
* */
public class Options extends AppCompatActivity {
//    FIELDS
    private String ftp_password = null;
    private String ftp_server = null;
    private int ftp_timing = 0;
    private  String ftp_username = "-1";
    private  String ftp_user = "-1";

//    OTHER CLASSES AND VIEW FIELDS
    private FTPEnogram client;
    private EditText pass, ftp, timme, username, user;
    private static ProgressBar mProgress;
    private Spinner crops;

    private Toast toastoptions;

//    LOCAL DATA
    private LocalData lc;
    private SharedPreferences.Editor editor;
    private SharedPreferences settings;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        /* this permission is important to permit FTP threads to work*/
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        /* see if activity was called from start or picture activity*/
        Bundle b = getIntent().getExtras();
        if( b != null){
            if(b.getInt("mode", 0) == 1){
                ImageButton options = (ImageButton) findViewById(R.id.picture_button);
                options.setVisibility(View.INVISIBLE);
            }
        }

        /* get shared preferences */
        settings = getSharedPreferences("ftp_data",MODE_PRIVATE);
        editor = settings.edit();

        /* Sets the user saved data in the view, and prepare the view*/
        client = new FTPEnogram(this, this);
        pass = (EditText) findViewById(R.id.ftp_password);
        ftp = (EditText) findViewById(R.id.ftp_server);
        timme = (EditText) findViewById(R.id.ftp_timing);
        username = (EditText) findViewById(R.id.ftp_username);
        user = (EditText) findViewById(R.id.ftp_user);
        crops = (Spinner) findViewById(R.id.crops_spinner);

        toastoptions = Toast.makeText(this, "Options saved", Toast.LENGTH_SHORT);


        ArrayAdapter<CharSequence> crop_adapter = ArrayAdapter.createFromResource(this,
                R.array.crop_list, android.R.layout.simple_spinner_item);

        crop_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        crops.setAdapter(crop_adapter);
        crops.setOnItemSelectedListener(new SpinnerActivity());


        lc = new LocalData();

        ftp_server = lc.getFtpServer(settings);
        ftp_password = lc.getFtpPassword(settings);
        ftp_username = lc.getFtpUsername(settings);
        ftp_timing = lc.getDistance(settings);
        ftp_user = lc.getFtpUser((settings));
        if(lc.isValidFtpServer(ftp_server)) {
            ftp.setText(ftp_server);
        }
        if(lc.isValidFtpPassword(ftp_password)){
            pass.setText(ftp_password);
        }
        if(lc.isValidDistance(ftp_timing)){
            timme.setText(""+ftp_timing);
        }
        if(lc.isValidFtpUsername(ftp_username)) {
            username.setText(ftp_username);
        }
        if(lc.isValidFtpUser(ftp_user)){
            user.setText(ftp_user);
        }
    }



    public void openMain(View view){
        Intent myIntent = new Intent(Options.this, MainBoard.class);
//        myIntent.putExtra("key", value); //Optional parameters
        Options.this.startActivity(myIntent);
    }

//    Save the options chosen by the user into the phone
    public void saveOptions(View view){
        ftp_password = pass.getText().toString();
        ftp_server = ftp.getText().toString();
        ftp_timing = Integer.parseInt(timme.getText().toString());
        ftp_user = user.getText().toString();
        ftp_username = username.getText().toString();

        lc.saveFtpPassword(ftp_password, editor);
        lc.saveFtpServer(ftp_server, editor);
        lc.saveDistance(ftp_timing, editor);
        lc.saveFtpUsername(ftp_username, editor);
        lc.saveFtpUser(ftp_user, editor);
        toastoptions.show();

    }

    public static class ProgressThread extends Thread {

        public void run() {
            mProgress.setVisibility(View.VISIBLE);
        }

        public static void main(String args[]) {
            (new ProgressThread()).start();
        }

    }


    public class SpinnerActivity extends Activity implements AdapterView.OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent, View view,
                                   int pos, long id) {
            String selected = parent.getItemAtPosition(pos).toString();
            System.out.println(selected);
            lc.saveCrop(selected, editor);
        }

        public void onNothingSelected(AdapterView<?> parent) {
            // Another interface callback
        }
    }

}
